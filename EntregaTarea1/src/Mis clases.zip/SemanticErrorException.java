
public class SemanticErrorException extends Exception
{
	public SemanticErrorException(String messageError)
	{
		super(messageError);
	}
}
